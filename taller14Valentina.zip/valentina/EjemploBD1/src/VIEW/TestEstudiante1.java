package VIEW;

import MODEL.Estudiante1;
import CONTROLER.ProcesarEstudiantes1;
import java.util.ArrayList;
import java.util.Scanner;

public class TestEstudiante1 {

    public static void main(String[] args) {
        Scanner pau_ent = new Scanner(System.in);
        String id;
        String nombre;
        double nota1;
        double nota2;
        ArrayList<Estudiante1> lstEst = new ArrayList<>();
        ProcesarEstudiantes1 procesarEstudiantes = new ProcesarEstudiantes1(lstEst);

        int opcion = 0;
        
        do {
            //Se crea un menu de opciones para que el usuario pueda escoger la opcion que guste.
            System.out.println("  \n          Bienvenido al Sistema Académico");
            System.out.println("=====================================================");
            System.out.println("                 Menú de Opciones");
            System.out.println("=====================================================");
            System.out.println("*Seleccione una opción del menú:");
            System.out.println("-Elija para insertar datos de un estudiante(1):");
            System.out.println("-Elija para leer datos del estudiante (2):");
            System.out.println("-Elija para actualizar datos del estudiante(3):");
            System.out.println("-Elija para borrar datos del estudiante(4):");
            System.out.println("-Elija para salir del sistema(0):");
            System.out.println("=====================================================");
            System.out.print("-Opción: ");
            opcion = pau_ent.nextInt();
            pau_ent.nextLine(); // Limpiar el buffer de entrada

            switch (opcion) {
                case 1:
                    System.out.println("\n =======================");
                    System.out.println("    Insertar datos");
                    System.out.println("=======================");
                    System.out.print("* Ingrese el nombre del estudiante: ");
                    nombre = pau_ent.nextLine();
                    System.out.print("* Ingrese su primera nota: ");
                    nota1 = pau_ent.nextDouble();
                    System.out.print("* Ingrese su segunda nota: ");
                    nota2 = pau_ent.nextDouble();
                    pau_ent.nextLine(); // Limpiar el buffer de entrada
                    System.out.print("* Ingrese su ID universitario: ");
                    id = pau_ent.nextLine();

                    Estudiante1 estudiante = new Estudiante1(nombre, nota1, nota2, id);
                    procesarEstudiantes.insertarEstudiante(estudiante);

                    System.out.println("\nEstudiante guardado correctamente.\n");
                    break;

                case 2:
                    System.out.println("\n=======================");
                    System.out.println("     'Leer datos'");
                    System.out.println("=======================");
                    ArrayList<Estudiante1> lstEstudiantes = procesarEstudiantes.getLstEstudiantes();
                    if (lstEstudiantes.isEmpty()) {
                        System.out.println("No hay estudiantes registrados.");
                    } else {
                        for (Estudiante1 est : lstEstudiantes) {
                            System.out.println(est);
                        }
                    }
                    break;

                case 3:
                    System.out.println("\n=======================");
                    System.out.println("   'Actualizar datos'");
                    System.out.println("=======================");
                    System.out.print("* Ingrese el ID del estudiante a actualizar: ");
                    id = pau_ent.nextLine();

                    boolean encontrado = false;
                    for (Estudiante1 est : procesarEstudiantes.getLstEstudiantes()) {
                        if (est.getId().equals(id)) {
                            encontrado = true;
                            System.out.println("\nDatos del estudiante encontrado:");
                            System.out.println(est);
                            System.out.println("\nSeleccione el dato que desea actualizar:");
                            System.out.println("-Nombre (1):");
                            System.out.println("-Nota 1 (2):");
                            System.out.println("-Nota 2 (3):");
                            System.out.println("-ID (4):");
                            System.out.print("Opción: ");
                            int opcionActualizacion = pau_ent.nextInt();
                            pau_ent.nextLine(); // Limpiar el buffer de entrada

                            switch (opcionActualizacion) {
                                case 1:
                                    System.out.print("Ingrese el nuevo nombre: ");
                                    nombre = pau_ent.nextLine();
                                    est.setNombreEst(nombre);
                                    break;
                                case 2:
                                    System.out.print("Ingrese la nueva nota 1: ");
                                    nota1 = pau_ent.nextDouble();
                                    est.setNota1(nota1);
                                    break;
                                case 3:
                                    System.out.print("Ingrese la nueva nota 2: ");
                                    nota2 = pau_ent.nextDouble();
                                    est.setNota2(nota2);
                                    break;
                                case 4:
                                    System.out.print("Ingrese el nuevo ID: ");
                                    id = pau_ent.nextLine();
                                    est.setId(id);
                                    break;
                                default:
                                    System.out.println("Opción no válida.");
                                    break;
                            }

                            procesarEstudiantes.actualizarEstudiante(est);
                            System.out.println("Datos actualizados correctamente.\n");
                            break; // Salir del bucle una vez encontrado y actualizado
                        }
                    }

                    if (!encontrado) {
                        System.out.println("No se encontró ningún estudiante con el ID proporcionado.");
                    }
                    break;

                case 4:
                    System.out.println("\n=======================");
                    System.out.println("   'Borrar datos'");
                    System.out.println("=======================");
                    System.out.print("* Ingrese el ID del estudiante a eliminar: ");
                    id = pau_ent.nextLine();
                    procesarEstudiantes.borrarEstudiante(id);
                    System.out.println("Estudiante eliminado correctamente.\n");
                    break;

                case 0:
                    System.out.println("\nSaliendo del programa, hasta pronto:)...");
                    break;

                default:
                    System.out.println("\nOpción no válida. Por favor ingrese un número del 0 al 4.");
                    break;
            }

        } while (opcion != 0);

        pau_ent.close();
    }
}