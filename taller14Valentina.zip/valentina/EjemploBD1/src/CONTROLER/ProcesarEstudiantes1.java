package CONTROLER;

import MODEL.Estudiante1;
import MODEL.ConeccionDB1;
import java.util.ArrayList;

public class ProcesarEstudiantes1 {
    private ArrayList<Estudiante1> lstEstudiantes;

    public ProcesarEstudiantes1(ArrayList<Estudiante1> lstEstudiantes) {
        this.lstEstudiantes = lstEstudiantes;
    }

    public void calculoPromedios() {
        for (Estudiante1 est : lstEstudiantes) {
            double promedio = (est.getNota1() + est.getNota2()) / 2.0;
            est.setPromedio(promedio);
        }
    }

    public void calculoEstados() {
        for (Estudiante1 est : lstEstudiantes) {
            String estado = (est.getPromedio() >= 7) ? "Aprobado" : "Reprobado";
            est.setEstado(estado);
        }
    }

    public void insertarEstudiante(Estudiante1 estudiante) {
        (new ConeccionDB1()).insertarEstudiante(estudiante); // Inserta en la base de datos
        lstEstudiantes.add(estudiante); // Agrega a la lista local
        calculoPromedios(); // Recalcula promedios localmente
        calculoEstados(); // Recalcula estados localmente
    }

    public ArrayList<Estudiante1> getLstEstudiantes() {
        return (new ConeccionDB1()).getLstEstudiantes(); // Obtiene lista de la base de datos
    }
    //UPDATE
    public void actualizarEstudiante(Estudiante1 estudiante) {
        (new ConeccionDB1()).updateEstudiante(estudiante); // Actualiza en la base de datos
        calculoPromedios(); // Recalcula promedios localmente
        calculoEstados(); // Recalcula estados localmente
    }
    //DELETED
    public void borrarEstudiante(String id) {
        (new ConeccionDB1()).deletedEstudiante(id); // Elimina de la base de datos
        lstEstudiantes.removeIf(est -> est.getId().equals(id)); // Elimina de la lista local
        calculoPromedios(); // Recalcula promedios localmente
        calculoEstados(); // Recalcula estados localmente
    }
}